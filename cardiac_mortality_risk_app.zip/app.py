
import streamlit as st
import numpy as np

st.set_page_config(page_title="Cardiac Mortality Risk Calculator", layout="centered")

st.title("🫀 Cardiac Mortality Risk Calculator")
st.markdown("Estimate a patient's cardiac mortality risk based on six key risk factors.")

# Input form
with st.form("risk_form"):
    st.subheader("Select Risk Factors:")
    hypertension = st.checkbox("Hypertension")
    diabetes = st.checkbox("Diabetes")
    family_history = st.checkbox("Family History of Heart Disease")
    smoking = st.checkbox("Cigarette Smoking")
    hyperlipidemia = st.checkbox("Hyperlipidemia")
    type_a_personality = st.checkbox("Type A Personality")

    submitted = st.form_submit_button("Calculate Risk")

def calculate_cardiac_mortality_risk(features):
    # Example logistic regression coefficients
    beta = {
        "intercept": -2.5,
        "hypertension": 0.9,
        "diabetes": 1.2,
        "family_history": 0.8,
        "smoking": 1.0,
        "hyperlipidemia": 0.7,
        "type_a_personality": 0.6
    }

    linear_combination = beta["intercept"]
    for key in features:
        linear_combination += features[key] * beta[key]

    probability = 1 / (1 + np.exp(-linear_combination))
    return round(probability, 3)

if submitted:
    inputs = {
        "hypertension": int(hypertension),
        "diabetes": int(diabetes),
        "family_history": int(family_history),
        "smoking": int(smoking),
        "hyperlipidemia": int(hyperlipidemia),
        "type_a_personality": int(type_a_personality)
    }
    risk = calculate_cardiac_mortality_risk(inputs)
    st.success(f"Estimated 10-year cardiac mortality risk: {risk * 100:.1f}%")
